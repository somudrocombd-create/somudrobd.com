-- SOMUDRO BD production database setup for Supabase
-- Run this entire file once in Supabase -> SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null check (category in ('perfume','attar','skincare')),
  price numeric(12,2) not null check (price >= 0),
  old_price numeric(12,2) check (old_price is null or old_price >= 0),
  badge text default 'NEW',
  subtitle text default '',
  description text default '',
  image_url text,
  visual_type text default 'wow',
  stock integer not null default 0 check (stock >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  district text not null,
  address text not null,
  items jsonb not null,
  subtotal numeric(12,2) not null default 0,
  status text not null default 'pending' check (status in ('pending','confirmed','processing','shipped','delivered','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  email text primary key,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.admin_users
    where lower(email) = lower(coalesce(auth.jwt()->>'email',''))
  );
$$;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists products_updated_at on public.products;
create trigger products_updated_at before update on public.products
for each row execute function public.set_updated_at();

drop trigger if exists orders_updated_at on public.orders;
create trigger orders_updated_at before update on public.orders
for each row execute function public.set_updated_at();

alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.admin_users enable row level security;

drop policy if exists "Public can read active products" on public.products;
create policy "Public can read active products"
on public.products for select
using (active = true or public.is_admin());

drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products"
on public.products for insert to authenticated
with check (public.is_admin());

drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products"
on public.products for update to authenticated
using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Admins can delete products" on public.products;
create policy "Admins can delete products"
on public.products for delete to authenticated
using (public.is_admin());

drop policy if exists "Anyone can create orders" on public.orders;
create policy "Anyone can create orders"
on public.orders for insert to anon, authenticated
with check (true);

drop policy if exists "Admins can read orders" on public.orders;
create policy "Admins can read orders"
on public.orders for select to authenticated
using (public.is_admin());

drop policy if exists "Admins can update orders" on public.orders;
create policy "Admins can update orders"
on public.orders for update to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Public product images. Admins can upload/update/delete files.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

drop policy if exists "Public can view product images" on storage.objects;
create policy "Public can view product images"
on storage.objects for select
using (bucket_id = 'product-images');

drop policy if exists "Admins can upload product images" on storage.objects;
create policy "Admins can upload product images"
on storage.objects for insert to authenticated
with check (bucket_id = 'product-images' and public.is_admin());

drop policy if exists "Admins can update product images" on storage.objects;
create policy "Admins can update product images"
on storage.objects for update to authenticated
using (bucket_id = 'product-images' and public.is_admin())
with check (bucket_id = 'product-images' and public.is_admin());

drop policy if exists "Admins can delete product images" on storage.objects;
create policy "Admins can delete product images"
on storage.objects for delete to authenticated
using (bucket_id = 'product-images' and public.is_admin());

-- Optional starter products. Safe to run once; duplicates are avoided by name.
insert into public.products (name, category, price, old_price, badge, subtitle, description, visual_type, stock)
select * from (values
 ('WOW Crazy Crush','perfume',720,850,'NEW','100ml • Long-lasting fragrance','Elegant everyday perfume with a premium presentation.','wow',20),
 ('Vampire Blood Perfume','perfume',550,650,'POPULAR','30ml • Bold fragrance','Deep, bold fragrance for evenings and special occasions.','vampire',20),
 ('White Rice Skin Beauty Serum','skincare',390,450,'SKINCARE','Brightening rice essence','Lightweight rice-based beauty essence for a simple daily routine.','rice',20),
 ('Dream Attar Collection','attar',520,650,'BEST SELLER','12 × 3ml • 12 fragrances','A gift-ready collection of 12 unique fragrance profiles.','wow',20),
 ('Dream Attar Lifestyle Set','attar',520,650,'GIFT READY','Premium presentation','A stylish fragrance set for gifting and everyday use.','wow',20),
 ('Eid Premium Fragrance Box','attar',950,1100,'LIMITED','Curated gift collection','A premium gift concept for Eid, weddings and special moments.','wow',20)
) as v(name,category,price,old_price,badge,subtitle,description,visual_type,stock)
where not exists (select 1 from public.products p where p.name = v.name);
