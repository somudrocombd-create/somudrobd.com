const seed = [
  {id:'wow',name:'WOW Crazy Crush',category:'perfume',price:720,old_price:850,badge:'NEW',subtitle:'100ml • Long-lasting fragrance',visual_type:'wow',description:'Elegant everyday perfume with a premium presentation.',stock:20},
  {id:'vampire',name:'Vampire Blood Perfume',category:'perfume',price:550,old_price:650,badge:'POPULAR',subtitle:'30ml • Bold fragrance',visual_type:'vampire',description:'Deep, bold fragrance for evenings and special occasions.',stock:20},
  {id:'rice',name:'White Rice Skin Beauty Serum',category:'skincare',price:390,old_price:450,badge:'SKINCARE',subtitle:'Brightening rice essence',visual_type:'rice',description:'Lightweight rice-based beauty essence for a simple daily routine.',stock:20},
  {id:'dream',name:'Dream Attar Collection',category:'attar',price:520,old_price:650,badge:'BEST SELLER',subtitle:'12 × 3ml • 12 fragrances',image_url:'assets/dream-attar-main.png',description:'A gift-ready collection of 12 unique fragrance profiles.',stock:20},
  {id:'dream2',name:'Dream Attar Lifestyle Set',category:'attar',price:520,old_price:650,badge:'GIFT READY',subtitle:'Premium presentation',image_url:'assets/dream-attar-lifestyle.png',description:'A stylish fragrance set for gifting and everyday use.',stock:20},
  {id:'eid',name:'Eid Premium Fragrance Box',category:'attar',price:950,old_price:1100,badge:'LIMITED',subtitle:'Curated gift collection',visual_type:'wow',description:'A premium gift concept for Eid, weddings and special moments.',stock:20}
];

const cfg = window.SOMUDRO_CONFIG;
const client = window.supabase?.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_PUBLISHABLE_KEY);
let products = [];
let cart = JSON.parse(localStorage.getItem('somudroCart') || '[]');
const money = n => '৳' + Number(n || 0).toLocaleString('en-BD');
const saveCart = () => localStorage.setItem('somudroCart', JSON.stringify(cart));

function normalise(p){return {...p, id:p.id, category:p.category || p.cat, old_price:p.old_price ?? p.old, subtitle:p.subtitle ?? p.sub, image_url:p.image_url ?? p.image, visual_type:p.visual_type ?? p.type, description:p.description ?? p.desc, stock:Number(p.stock ?? 0)}}
async function loadProducts(){
  if(!client){products = seed; render(); renderCart(); return;}
  const {data,error}=await client.from('products').select('*').eq('active',true).order('created_at',{ascending:false});
  products = error ? seed : (data || []).map(normalise);
  if(error) console.warn('Supabase products unavailable:', error.message);
  render(); renderCart();
}
function visual(p){
  if(p.image_url) return `<img src="${p.image_url}" alt="${escapeHtml(p.name)}" loading="lazy">`;
  return `<div class="fake ${p.visual_type||'wow'}"><span>${p.visual_type==='rice'?'WHITE RICE':p.visual_type==='vampire'?'VAMPIRE':'WOW'}</span><b>${p.visual_type==='rice'?'SKIN BEAUTY SERUM':p.visual_type==='vampire'?'BLOOD PERFUME':'CRAZY CRUSH'}</b></div>`;
}
function escapeHtml(s=''){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function render(){
  const q=(document.getElementById('search').value||'').toLowerCase().trim(), cat=document.getElementById('filter').value;
  const list=products.filter(p=>(cat==='all'||p.category===cat)&&(p.name+' '+p.subtitle+' '+p.description).toLowerCase().includes(q));
  document.getElementById('products').innerHTML=list.length?list.map(p=>`<article class="product"><div class="visual">${visual(p)}<span class="tag">${escapeHtml(p.badge||'NEW')}</span></div><div class="info"><h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.subtitle||'')}</p><div class="price"><b>${money(p.price)}</b><del>${p.old_price?money(p.old_price):''}</del></div><div class="card-actions"><button class="buy" onclick="buy('${p.id}')" ${p.stock<=0?'disabled':''}>${p.stock<=0?'Out of stock':'Buy Now'}</button><button class="add" onclick="add('${p.id}')" ${p.stock<=0?'disabled':''}>Add to Cart</button></div></div></article>`).join(''):'<div class="empty">No products found. Try another search or category.</div>';
}
function getProduct(id){return products.find(p=>String(p.id)===String(id));}
function add(id,qty=1){const p=getProduct(id);if(!p||p.stock<=0)return alert('This product is currently out of stock.');const i=cart.find(x=>x.id===id);if(i)i.qty=Math.min(i.qty+qty,p.stock);else cart.push({id,qty:Math.min(qty,p.stock)});saveCart();renderCart();openDrawer()}
function buy(id){cart=[{id,qty:1}];saveCart();openCheckout()}
function renderCart(){
  const box=document.getElementById('cartItems');let total=0,count=0;
  if(!cart.length) box.innerHTML='<div class="empty">Your cart is empty.</div>';
  else box.innerHTML=cart.map(i=>{const p=getProduct(i.id);if(!p)return '';const qty=Math.min(i.qty,p.stock||i.qty),sub=p.price*qty;total+=sub;count+=qty;return `<div class="cart-row"><div><b>${escapeHtml(p.name)}</b><small>${money(p.price)} × ${qty}</small></div><div class="qty"><button onclick="change('${p.id}',-1)">−</button><span>${qty}</span><button onclick="change('${p.id}',1)">+</button></div></div>`}).join('');
  document.getElementById('total').textContent=money(total);document.getElementById('count').textContent=count;
}
function change(id,d){const i=cart.find(x=>x.id===id),p=getProduct(id);if(!i||!p)return;i.qty+=d;if(i.qty<=0)cart=cart.filter(x=>x.id!==id);else i.qty=Math.min(i.qty,p.stock||i.qty);saveCart();renderCart()}
function openDrawer(){document.getElementById('drawer').classList.add('open');document.getElementById('overlay').classList.add('show')}
function closeDrawer(){document.getElementById('drawer').classList.remove('open');document.getElementById('overlay').classList.remove('show')}
function summary(){let total=0;document.getElementById('summary').innerHTML=cart.map(i=>{const p=getProduct(i.id),qty=Math.min(i.qty,p.stock||i.qty),s=p.price*qty;total+=s;return `<div class="summary-row"><span>${escapeHtml(p.name)} × ${qty}</span><b>${money(s)}</b></div>`}).join('')+`<div class="summary-total"><span>Subtotal</span><span>${money(total)}</span></div>`}
function openCheckout(){if(!cart.length)return alert('Cart is empty');closeDrawer();summary();document.getElementById('modal').classList.add('open')}
function closeCheckout(){document.getElementById('modal').classList.remove('open')}
function orderPayload(){let total=0;const items=cart.map(i=>{const p=getProduct(i.id),qty=Math.min(i.qty,p.stock||i.qty),s=p.price*qty;total+=s;return {product_id:p.id,name:p.name,price:p.price,quantity:qty,line_total:s}});return {customer_name:document.getElementById('name').value.trim(),phone:document.getElementById('phone').value.trim(),district:document.getElementById('district').value.trim(),address:document.getElementById('address').value.trim(),items,subtotal:total}}
function waMessage(o){return `Hello SOMUDRO BD,\n\nI want to order:\n${o.items.map(x=>`• ${x.name} × ${x.quantity} — ${money(x.line_total)}`).join('\n')}\n\nSubtotal: ${money(o.subtotal)}\nName: ${o.customer_name}\nPhone: ${o.phone}\nDistrict: ${o.district}\nAddress: ${o.address}`}

async function submitOrder(o){
  if(client){const {error}=await client.from('orders').insert(o);if(error)console.warn('Order database save failed:',error.message)}
  window.open('https://wa.me/'+cfg.WHATSAPP_NUMBER+'?text='+encodeURIComponent(waMessage(o)),'_blank');
  cart=[];saveCart();renderCart();closeCheckout();
}

document.getElementById('search').addEventListener('input',render);
document.getElementById('filter').addEventListener('change',render);
document.querySelectorAll('[data-cat]').forEach(b=>b.addEventListener('click',()=>{document.getElementById('filter').value=b.dataset.cat;document.getElementById('shop').scrollIntoView({behavior:'smooth'});render()}));
document.getElementById('cartOpen').onclick=openDrawer;document.getElementById('close').onclick=closeDrawer;document.getElementById('overlay').onclick=closeDrawer;document.getElementById('checkout').onclick=openCheckout;document.getElementById('modalClose').onclick=closeCheckout;
document.getElementById('waCart').onclick=()=>{if(!cart.length)return;const o=orderPayload();window.open('https://wa.me/'+cfg.WHATSAPP_NUMBER+'?text='+encodeURIComponent(waMessage(o)),'_blank')};
document.getElementById('orderForm').onsubmit=async e=>{e.preventDefault();const o=orderPayload();await submitOrder(o)};
document.getElementById('menu').onclick=()=>document.getElementById('nav').classList.toggle('open');document.getElementById('year').textContent=new Date().getFullYear();loadProducts();
