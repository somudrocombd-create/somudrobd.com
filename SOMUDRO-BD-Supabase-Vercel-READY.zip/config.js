window.SOMUDRO_CONFIG = {
  SUPABASE_URL: 'https://afeahsiunexmzkkapqup.supabase.co',
  SUPABASE_PUBLISHABLE_KEY: 'sb_publishable__pshhknH_g34-n9lkmoSAg_Vn4WFHvl',
  WHATSAPP_NUMBER: '8801410753899'
};
