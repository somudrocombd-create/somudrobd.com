# SOMUDRO BD — Supabase + Vercel E-commerce

Production-ready static storefront with Supabase database, authentication, product management, image storage, orders and WhatsApp checkout.

## Files
- `index.html` — customer storefront
- `admin.html` — secure Supabase admin dashboard
- `config.js` — Supabase project URL + publishable key
- `supabase-schema.sql` — database, RLS, storage and starter products
- `style.css` — premium responsive design
- `script.js` — storefront logic
- `assets/` — starter product images

## 1. Configure Supabase
1. Open Supabase SQL Editor.
2. Open `supabase-schema.sql` from this ZIP and run the complete file.
3. Open `admin.html` after deployment and create an account with your admin email.
4. In Supabase SQL Editor, run:

```sql
insert into public.admin_users (email)
values ('YOUR-ADMIN-EMAIL@example.com')
on conflict (email) do nothing;
```

Replace the email with the exact email used for the admin account.

If email confirmation is enabled, confirm the email first.

## 2. Deploy to Vercel
1. Upload/extract these files into your GitHub repository root.
2. Import the repository into Vercel.
3. Framework preset: **Other**.
4. Build command: leave empty.
5. Output directory: `.`
6. Deploy.

## 3. Important security note
`config.js` contains the Supabase **publishable** key. That key is intended for browser applications. Never put a `service_role` or `sb_secret_...` key in this project.

## 4. Features
- Multi-product catalog backed by Supabase
- Search and category filtering
- Cart and quantity controls
- Customer orders saved to Supabase
- WhatsApp order handoff
- Admin login with Supabase Auth
- Admin product CRUD
- Stock management
- Product image upload to Supabase Storage
- Order management and status updates
- Row Level Security policies
