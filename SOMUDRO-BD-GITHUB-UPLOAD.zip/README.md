# SOMUDRO BD — EcomStore-style storefront

Premium multi-product storefront adapted from the uploaded SOMUDRO BD site.

## Included
- Responsive premium storefront
- Product search + category filter
- Cart + quantity controls
- WhatsApp checkout to 01410753899
- Product catalog seeded with perfume, attar and skincare examples
- `admin.html` lightweight browser-local product manager
- Vercel-ready static deployment

## Deploy to Vercel
1. Upload this folder to a GitHub repository.
2. In Vercel, import the repository.
3. Framework preset can be **Other** because this is a static HTML/CSS/JS site.
4. Build command: leave empty.
5. Output directory: `.`
6. Deploy.

## Important admin note
The included `admin.html` is a local catalog manager using browser `localStorage`. It is useful for a prototype/demo but is **not** a secure multi-user production admin panel. For real production product management, use Supabase/Postgres + authentication + image storage.
