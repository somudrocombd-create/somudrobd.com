SOMUDRO BD - Vercel/GitHub Upload Ready

IMPORTANT:
1. Extract this ZIP.
2. Upload ALL files/folders INSIDE this folder to the ROOT of your GitHub repository.
3. Do NOT upload the ZIP itself to GitHub.
4. Vercel can deploy this repository as a static site with no build command.
5. Open index.html as the storefront and admin.html for the local browser catalog manager.

Note: The included admin catalog currently uses browser localStorage. It is not a shared production database.
